import network
print(network.WLAN().config('mac'))